package com.whiteclient.module.impl;

import com.whiteclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class ESP extends Module {

    public ESP() { super("ESP"); }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (!isEnabled()) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;

        float pt  = event.getPartialTicks();
        Entity rv = mc.getRenderViewEntity();

        double cx = rv.lastTickPosX + (rv.posX - rv.lastTickPosX) * pt;
        double cy = rv.lastTickPosY + (rv.posY - rv.lastTickPosY) * pt;
        double cz = rv.lastTickPosZ + (rv.posZ - rv.lastTickPosZ) * pt;

        GL11.glPushMatrix();
        GL11.glTranslated(-cx, -cy, -cz);

        GL11.glLineWidth(2.0f);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);

        for (EntityPlayer player : mc.world.playerEntities) {
            if (player == mc.player) continue;

            double ex = player.lastTickPosX + (player.posX - player.lastTickPosX) * pt;
            double ey = player.lastTickPosY + (player.posY - player.lastTickPosY) * pt;
            double ez = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * pt;

            AxisAlignedBB bb = player.getEntityBoundingBox()
                    .offset(-player.posX + ex, -player.posY + ey, -player.posZ + ez);

            RenderGlobal.drawSelectionBoundingBox(bb, 1.0f, 0.2f, 0.2f, 1.0f);
        }

        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glPopMatrix();
    }
}
