package com.whiteclient.module;

import com.whiteclient.module.impl.*;
import net.minecraftforge.common.MinecraftForge;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        register(new Fly());
        register(new Speed());
        register(new NoFall());
        register(new FullBright());
        register(new Jesus());
        register(new KillAura());
        register(new ESP());
    }

    private void register(Module m) {
        modules.add(m);
        MinecraftForge.EVENT_BUS.register(m);
    }

    public List<Module> getModules() { return modules; }
}
