package com.whiteclient.module.impl;

import com.whiteclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class KillAura extends Module {

    public KillAura() { super("KillAura"); }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (!isEnabled()) return;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;

        Entity target = null;
        double best   = 4.5 * 4.5;

        for (Entity e : mc.world.loadedEntityList) {
            if (e == mc.player) continue;
            if (!(e instanceof EntityLivingBase)) continue;
            if (e instanceof EntityPlayer) {
                EntityPlayer p = (EntityPlayer) e;
                if (p.isInvisible()) continue;
            }
            double d = mc.player.getDistanceSq(e);
            if (d < best) { best = d; target = e; }
        }

        if (target != null) {
            mc.playerController.attackEntity(mc.player, target);
            mc.player.swingArm(EnumHand.MAIN_HAND);
        }
    }
}
