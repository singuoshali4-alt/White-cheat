package com.whiteclient.module.impl;

import com.whiteclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Speed extends Module {

    public Speed() { super("Speed"); }

    @SubscribeEvent
    public void onUpdate(LivingEvent.LivingUpdateEvent event) {
        if (!isEnabled()) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        if (event.getEntityLiving() != mc.player) return;

        mc.player.motionX *= 2.8;
        mc.player.motionZ *= 2.8;
    }
}
