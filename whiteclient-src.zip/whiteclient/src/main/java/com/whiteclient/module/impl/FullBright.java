package com.whiteclient.module.impl;

import com.whiteclient.module.Module;
import net.minecraft.client.Minecraft;

public class FullBright extends Module {

    private float savedGamma;

    public FullBright() { super("FullBright"); }

    @Override
    public void onEnable() {
        Minecraft mc = Minecraft.getMinecraft();
        savedGamma = mc.gameSettings.gammaSetting;
        mc.gameSettings.gammaSetting = 1000.0f;
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings != null) {
            mc.gameSettings.gammaSetting = savedGamma;
        }
    }
}
