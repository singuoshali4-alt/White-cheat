package com.whiteclient.module.impl;

import com.whiteclient.module.Module;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Jesus extends Module {

    public Jesus() { super("Jesus"); }

    @SubscribeEvent
    public void onUpdate(LivingEvent.LivingUpdateEvent event) {
        if (!isEnabled()) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        if (event.getEntityLiving() != mc.player) return;

        BlockPos pos = new BlockPos(mc.player.posX, mc.player.posY - 0.01, mc.player.posZ);
        Material mat = mc.world.getBlockState(pos).getMaterial();

        if (mat == Material.WATER || mat == Material.LAVA) {
            if (mc.player.motionY < 0) {
                mc.player.motionY = 0.05;
            }
            mc.player.onGround  = true;
            mc.player.fallDistance = 0;
        }
    }
}
