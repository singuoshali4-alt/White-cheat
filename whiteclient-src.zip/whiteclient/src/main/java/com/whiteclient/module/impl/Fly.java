package com.whiteclient.module.impl;

import com.whiteclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class Fly extends Module {

    public Fly() { super("Fly"); }

    @SubscribeEvent
    public void onUpdate(LivingEvent.LivingUpdateEvent event) {
        if (!isEnabled()) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (!(event.getEntityLiving() instanceof EntityPlayer)) return;
        if (event.getEntityLiving() != mc.player) return;

        mc.player.capabilities.allowFlying = true;
        mc.player.capabilities.isFlying    = true;
        mc.player.fallDistance = 0;

        boolean jump  = Keyboard.isKeyDown(mc.gameSettings.keyBindJump.getKeyCode());
        boolean sneak = Keyboard.isKeyDown(mc.gameSettings.keyBindSneak.getKeyCode());

        if      (jump)  mc.player.motionY =  0.25;
        else if (sneak) mc.player.motionY = -0.25;
        else            mc.player.motionY =  0;
    }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null && !mc.player.capabilities.isCreativeMode) {
            mc.player.capabilities.allowFlying = false;
            mc.player.capabilities.isFlying    = false;
        }
    }
}
