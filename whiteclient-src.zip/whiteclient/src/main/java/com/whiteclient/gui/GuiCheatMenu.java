package com.whiteclient.gui;

import com.whiteclient.WhiteClient;
import com.whiteclient.module.Module;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;
import java.util.List;

public class GuiCheatMenu extends GuiScreen {

    @Override
    public void initGui() {
        List<Module> modules = WhiteClient.moduleManager.getModules();
        int startX = width / 2 - 105;
        int startY = 40;
        for (int i = 0; i < modules.size(); i++) {
            Module m = modules.get(i);
            addButton(new GuiButton(i, startX, startY + i * 26, 210, 20, label(m)));
        }
    }

    private String label(Module m) {
        return m.getName() + "  " + (m.isEnabled() ? "\u00a7a[ON]" : "\u00a7c[OFF]");
    }

    @Override
    protected void actionPerformed(GuiButton btn) throws IOException {
        List<Module> modules = WhiteClient.moduleManager.getModules();
        if (btn.id >= 0 && btn.id < modules.size()) {
            Module m = modules.get(btn.id);
            m.toggle();
            btn.displayString = label(m);
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, "\u00a76White\u00a7fClient \u00a77\u00bb \u00a7eF \u00a77\u00bb \u00a7fclose", width / 2, 14, 0xFFFFFF);
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
