package com.whiteclient;

import com.whiteclient.gui.GuiCheatMenu;
import com.whiteclient.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = WhiteClient.MODID, name = WhiteClient.NAME, version = WhiteClient.VERSION, clientSideOnly = true)
public class WhiteClient {

    public static final String MODID   = "whiteclient";
    public static final String NAME    = "WhiteClient";
    public static final String VERSION = "1.0";

    public static ModuleManager moduleManager;
    public static KeyBinding menuKey;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        moduleManager = new ModuleManager();
        menuKey = new KeyBinding("Open Cheat Menu", Keyboard.KEY_F, "WhiteClient");
        ClientRegistry.registerKeyBinding(menuKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen == null && menuKey.isPressed()) {
            mc.displayGuiScreen(new GuiCheatMenu());
        }
    }
}
